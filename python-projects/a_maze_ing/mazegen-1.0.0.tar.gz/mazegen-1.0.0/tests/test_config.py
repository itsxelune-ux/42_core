from pathlib import Path

import pytest
from maze.config import (
    parse_config,
    validate_config,
    MazeConfig,
    ConfigFileNotFound,
    ConfigMissingKeys,
    ConfigValueError,
)


def write_config_file(
    tmp_path: Path, content: str
) -> Path:
    file_path = tmp_path / "config.txt"
    file_path.write_text(content)
    return file_path


def test_valid_config(tmp_path: Path) -> None:
    content = """
    WIDTH=10
    HEIGHT=8
    ENTRY=0,0
    EXIT=9,7
    OUTPUT_FILE=maze.png
    PERFECT=True
    SEED=123
    ALGORITHM=dfs
    """
    path = write_config_file(tmp_path, content)
    raw = parse_config(str(path))
    config = validate_config(raw)
    assert isinstance(config, MazeConfig)
    assert config.width == 10
    assert config.height == 8
    assert config.entry == (0, 0)
    assert config.exit == (9, 7)
    assert config.output_file == "maze.png"
    assert config.perfect is True
    assert config.seed == 123
    assert config.algorithm == "dfs"


def test_missing_keys(tmp_path: Path) -> None:
    content = """
    WIDTH=10
    HEIGHT=8
    ENTRY=0,0
    EXIT=9,7
    PERFECT=True
    """
    path = write_config_file(tmp_path, content)
    raw = parse_config(str(path))
    with pytest.raises(ConfigMissingKeys) as exc:
        validate_config(raw)
    assert "OUTPUT_FILE" in str(exc.value)


@pytest.mark.parametrize(
    "content, error_text",
    [
        (
            "WIDTH=abc\nHEIGHT=8\nENTRY=0,0\n"
            "EXIT=9,7\nOUTPUT_FILE=m.png\nPERFECT=True",
            "WIDTH",
        ),
        (
            "WIDTH=10\nHEIGHT=xyz\nENTRY=0,0\n"
            "EXIT=9,7\nOUTPUT_FILE=m.png\nPERFECT=True",
            "HEIGHT",
        ),
        (
            "WIDTH=10\nHEIGHT=8\nENTRY=not,coords\n"
            "EXIT=9,7\nOUTPUT_FILE=m.png\nPERFECT=True",
            "ENTRY",
        ),
        (
            "WIDTH=10\nHEIGHT=8\nENTRY=0,0\n"
            "EXIT=9,7\nOUTPUT_FILE=m.png\nPERFECT=maybe",
            "PERFECT",
        ),
    ]
)
def test_invalid_values(
    tmp_path: Path, content: str, error_text: str
) -> None:
    path = write_config_file(tmp_path, content)
    raw = parse_config(str(path))
    with pytest.raises(ConfigValueError) as exc:
        validate_config(raw)
    assert error_text in str(exc.value)


def test_comments_and_blank_lines(
    tmp_path: Path,
) -> None:
    content = """
    # This is a comment
    WIDTH=10

    HEIGHT=8
    ENTRY=0,0
    EXIT=9,7
    OUTPUT_FILE=maze.png
    PERFECT=True
    """
    path = write_config_file(tmp_path, content)
    raw = parse_config(str(path))
    config = validate_config(raw)
    assert config.width == 10
    assert config.height == 8


def test_whitespace_around_equal(
    tmp_path: Path,
) -> None:
    content = """
    WIDTH = 10
    HEIGHT = 8
    ENTRY = 0,0
    EXIT = 9,7
    OUTPUT_FILE = maze.png
    PERFECT = True
    """
    path = write_config_file(tmp_path, content)
    raw = parse_config(str(path))
    config = validate_config(raw)
    assert config.width == 10
    assert config.output_file == "maze.png"


def test_file_not_found() -> None:
    with pytest.raises(ConfigFileNotFound) as exc:
        parse_config("nonexistent.txt")
    assert "not found" in str(exc.value)


def test_entry_exit_out_of_bounds(
    tmp_path: Path,
) -> None:
    content = """
    WIDTH=10
    HEIGHT=8
    ENTRY=10,0
    EXIT=9,7
    OUTPUT_FILE=maze.png
    PERFECT=True
    """
    path = write_config_file(tmp_path, content)
    raw = parse_config(str(path))
    with pytest.raises(ConfigValueError) as exc:
        validate_config(raw)
    assert "ENTRY coordinates" in str(exc.value)


def test_entry_equals_exit(tmp_path: Path) -> None:
    content = """
    WIDTH=10
    HEIGHT=8
    ENTRY=0,0
    EXIT=0,0
    OUTPUT_FILE=maze.png
    PERFECT=True
    """
    path = write_config_file(tmp_path, content)
    raw = parse_config(str(path))
    with pytest.raises(ConfigValueError) as exc:
        validate_config(raw)
    assert "ENTRY and EXIT must be different" in str(
        exc.value
    )
