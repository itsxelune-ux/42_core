# tests/test_maze.py
from maze.generator import Maze, Cell


def test_new_maze_all_walls_closed() -> None:
    maze = Maze(5, 5, entry=(0, 0), exit=(4, 4))
    for y in range(maze.height):
        for x in range(maze.width):
            cell = maze.get_cell(x, y)
            assert cell.north
            assert cell.east
            assert cell.south
            assert cell.west


def test_open_wall_opposite_also_opens() -> None:
    maze = Maze(5, 5, entry=(0, 0), exit=(4, 4))
    maze.open_wall(2, 3, "E")
    cell = maze.get_cell(2, 3)
    neighbor = maze.get_cell(3, 3)
    assert not cell.east
    assert not neighbor.west


def test_open_wall_on_border_does_not_crash() -> None:
    maze = Maze(5, 5, entry=(0, 0), exit=(4, 4))
    maze.open_wall(0, 0, "N")
    cell = maze.get_cell(0, 0)
    assert not cell.north


def test_enforce_borders_closes_edge_walls() -> None:
    maze = Maze(5, 5, entry=(0, 0), exit=(4, 4))
    maze.get_cell(0, 0).north = False
    maze.get_cell(0, 0).west = False
    maze.enforce_borders()
    for x in range(5):
        assert maze.get_cell(x, 0).north
    for x in range(5):
        assert maze.get_cell(x, 4).south
    for y in range(5):
        assert maze.get_cell(0, y).west
    for y in range(5):
        assert maze.get_cell(4, y).east


def test_cell_to_hex() -> None:
    cell = Cell(0, 0)
    assert cell.to_hex() == "F"
    cell = Cell(0, 0, False, False, False, False)
    assert cell.to_hex() == "0"
    cell = Cell(0, 0, False, True, True, True)
    assert cell.to_hex() == "E"
    cell = Cell(0, 0, True, False, True, True)
    assert cell.to_hex() == "D"
    cell = Cell(0, 0, True, True, False, True)
    assert cell.to_hex() == "B"
    cell = Cell(0, 0, True, True, True, False)
    assert cell.to_hex() == "7"
